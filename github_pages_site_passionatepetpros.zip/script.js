// Tiny helpers
const yr = document.getElementById('year');
if (yr) yr.textContent = new Date().getFullYear();
